# WhyyyMDB

This is a IMDB clone built using `ReactJS` with TMDB API

![home.jpg](./assets/home.jpg)
